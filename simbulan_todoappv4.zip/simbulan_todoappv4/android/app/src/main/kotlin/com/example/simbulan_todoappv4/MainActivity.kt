package com.example.simbulan_todoappv4

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
