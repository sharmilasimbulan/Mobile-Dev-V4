import 'package:flutter/material.dart';
import 'package:simbulan_todoappv4/widgets/gradient_button.dart';
import 'package:simbulan_todoappv4/widgets/login_field.dart';
import 'package:simbulan_todoappv4/homepage.dart';
import 'package:simbulan_todoappv4/main.dart';


class LoginScreen extends StatelessWidget {

  LoginScreen({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: [
              Image.asset('assets/images/logo.png'),
    Column(
    children: [
    const Column(
    children: [
    SizedBox(height: 30)

    ],
    ),

      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 40),
        child: Container(
          padding: const EdgeInsets.only(top: 3,left: 3),
          decoration: BoxDecoration(
          ),
          child: MaterialButton(
            minWidth: double.infinity,
            height:60,
            onPressed: (){Navigator.push(
                context, MaterialPageRoute(builder: (_) => MyHomePage()));
              },
            color: Colors.indigoAccent[400],
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(40)
            ),
            child: const Text("Start",style: TextStyle(
                fontWeight: FontWeight.w600,fontSize: 23,color: Colors.white70
            ),),
          ),
        ),
      ),
            ],
          ),
        ],
      )
      )
    ),
    );

  }
}






