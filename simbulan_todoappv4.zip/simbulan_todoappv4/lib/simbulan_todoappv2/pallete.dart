import 'package:flutter/material.dart';

class Pallete {
  static const Color backgroundColor = Color.fromRGBO(46, 61, 80, 1.0);
  static const Color whiteColor = Colors.white;
}
